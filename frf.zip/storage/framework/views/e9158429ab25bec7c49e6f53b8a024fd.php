<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.4.3/dist/css/tom-select.css" rel="stylesheet">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css',
            'resources/js/app.js']); ?>

</head>
<body class="d-flex flex-column min-vh-100">

    <?php echo $__env->make('components.user.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="flex-grow-1">

        <?php echo $__env->yieldContent('maincontent'); ?>

    </main>

    <?php echo $__env->make('components.user.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.4.3/dist/js/tom-select.complete.min.js"></script>
</body>

</html><?php /**PATH F:\KULIAH\smt 8\Forum Review Film Skripsi\FRF-Skripsi\resources\views/mainlayout.blade.php ENDPATH**/ ?>