

<?php $__env->startSection('maincontent'); ?>
<div id="heroCarousel"
     class="carousel slide"
     data-bs-ride="carousel">

    <div class="carousel-inner">

        

            <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">

                    <div class="carousel-img-wrapper">
                
                        <img src="https://image.tmdb.org/t/p/original<?php echo e($film->banner); ?>"
                            class="carousel-img">
                
                </div>
                    <div class="carousel-caption custom-caption">
        
                        <h1><?php echo e($film->judul); ?></h1>
        
                        <p>
                            <?php echo e(Str::limit($film->sinopsis, 100)); ?>

                        </p>
        
                        <a href="<?php echo e(url('/listFilm/' . $film->id)); ?>"
                           class="btn btn-warning">
        
                            Lihat Detail
        
                        </a>
        
                    </div>
        
                </div>
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        

    </div>

    <!-- BUTTON PREV -->
    <button class="carousel-control-prev"
            type="button"
            data-bs-target="#heroCarousel"
            data-bs-slide="prev">

        <span class="carousel-control-prev-icon"></span>

    </button>

    <!-- BUTTON NEXT -->
    <button class="carousel-control-next"
            type="button"
            data-bs-target="#heroCarousel"
            data-bs-slide="next">

        <span class="carousel-control-next-icon"></span>

    </button>

</div>


<section class="container my-5">

    <div class="d-flex justify-content-between align-items-center mb-3">

        <h4 class="text-white">TRENDING</h4>

        <a href="/listFilm" class="text-primary">See All →</a>

    </div>

    <div class="movie-scroll">
        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- CARD -->
            <div class="movie-card">
                <a href="<?php echo e(url('/listFilm/' . $film->id)); ?>">
                    <img src="https://image.tmdb.org/t/p/original<?php echo e($film->poster); ?>">
                    <h6><?php echo e($film->judul); ?></h6>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div>

</section>
<hr>

<section class="container px-5 my-5">
    <div class="font font-color my-5">
        <h3 class="text-center">
            About Us
        </h3>
        <p class="text-center">
            Forum Review Film hadir sebagai tempat berkumpulnya para pecinta film untuk berdiskusi, membagikan teori, memberikan ulasan, dan mengikuti perkembangan terbaru dunia perfilman. Mulai dari berita terkini, review dari para cinephile, hingga teori menarik antar semesta film, semuanya dapat ditemukan dan didiskusikan bersama di sini.
        </p>
    </div>
</section>
<hr>


<section class="container my-5">
    <h4 class="text-white">
        Artikel
    </h4>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- berita 1 -->
    <div class="row article-card align-items-center">

        <!-- GAMBAR -->
        <div class="col-md-4">
            <img src="<?php echo e(asset('storage/' . $article->gambar_cover)); ?>">
        </div>

        <!-- TEXT -->
        <div class="col-md-8 font-color">

            <h3><?php echo e($article->judul); ?></h3>

            <p>
                <?php echo e(Str::limit($article->isi_awal, 100)); ?>

            </p>

            <a href="#" class="btn btn-primary">
                Baca Selengkapnya
            </a>

        </div>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</section>

<script>
    const container = document.querySelector('.movie-scroll');
    
    container.addEventListener('wheel', function (e) {
        e.preventDefault(); // stop scroll vertikal halaman
    
        container.scrollLeft += e.deltaY;
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\KULIAH\smt 8\Forum Review Film Skripsi\FRF-Skripsi\resources\views/pages/home.blade.php ENDPATH**/ ?>